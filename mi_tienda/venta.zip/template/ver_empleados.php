<?php
include '../db/config.php';
include '../includes/header.php';
session_start();
if (!isset($_SESSION["usuario"])) {
    header("Location: ../auth/login.php");
    exit();
}
?>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container">
        <a class="navbar-brand" href="#">Panel de Control</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="../index.php">Volver a la Pagina Principal</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="container mt-5">
    <div class="card p-4 shadow text-center">
        <h2>Lista de Empleados</h2>
    </div>

    <div class="row mt-4">
        <div class="col-md-12">
            <div class="card p-3 shadow">
                <!-- Botón para agregar un nuevo empleado -->
                <a href="formulario_empleado.php" class="btn btn-success mb-3">Agregar Empleado</a>
                
                <table class="table table-bordered">
                    <?php
                    if (isset($_GET['mensaje'])) {
                        echo "<div class='alert alert-success'>{$_GET['mensaje']}</div>";
                    }
                    ?>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Puesto</th>
                            <th>Teléfono</th>
                            <th>Email</th>
                            <th>Fecha de Ingreso</th>
                            <th>Salario</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Obtener lista de empleados
                        $query = $conn->query("SELECT * FROM empleados");
                        while ($row = $query->fetch_assoc()) {
                            echo "<tr>
                                    <td>{$row['id']}</td>
                                    <td>{$row['nombre']} {$row['apellido']}</td>
                                    <td>{$row['puesto']}</td>
                                    <td>{$row['telefono']}</td>
                                    <td>{$row['email']}</td>
                                    <td>{$row['fecha_ingreso']}</td>
                                    <td>{$row['salario']}</td>
                                    <td>
                                        <a href='empleados/editar_empleado.php?id={$row['id']}' class='btn btn-warning'>Editar</a>
                                        <a href='empleados/despedir_empleado.php?id={$row['id']}' class='btn btn-danger' onclick='return confirm(\"¿Seguro que deseas despedir a este empleado?\")'>Despedir</a>
                                    </td>
                                  </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>