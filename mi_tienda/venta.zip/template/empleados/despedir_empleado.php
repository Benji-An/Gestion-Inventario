<?php

include('../../db/config.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "DELETE FROM empleados WHERE id = ?";

    // Preparar la consulta
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $id);  
        if ($stmt->execute()) {
            header("Location: ../ver_empleados.php?mensaje=Empleado despedido con éxito");
        } else {
            echo "Error al eliminar el empleado";
        }
    } else {
        echo "Error al preparar la consulta";
    }

    $conn->close();
} else {
    echo "No se ha recibido el ID del empleado";
}
?>
