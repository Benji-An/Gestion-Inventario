<?php
include '../db/config.php';
include '../includes/header.php';
session_start();
if (!isset($_SESSION["usuario"])) {
    header("Location: ../auth/login.php");
    exit();
}

$busqueda = $_GET['buscar'] ?? '';

// Datos para tabla y gráfica
$stmt = $conn->prepare("
    SELECT 
        c.producto, 
        SUM(c.cantidad) AS total_comprado,
        IFNULL((SELECT SUM(v.cantidad) FROM ventas v WHERE v.producto = c.producto), 0) AS total_vendido
    FROM compras c
    WHERE c.producto LIKE ?
    GROUP BY c.producto
");
$like = "%$busqueda%";
$stmt->bind_param("s", $like);
$stmt->execute();
$resultado = $stmt->get_result();

// Guardamos datos para Chart.js
$productos = [];
$stocks = [];

while ($row = $resultado->fetch_assoc()) {
    $stock = $row['total_comprado'] - $row['total_vendido'];
    $productos[] = $row['producto'];
    $stocks[] = $stock;
    $tabla[] = [
        'producto' => $row['producto'],
        'total_comprado' => $row['total_comprado'],
        'total_vendido' => $row['total_vendido'],
        'stock' => $stock
    ];
}
?>

<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container">
        <a class="navbar-brand" href="#">Panel de Control</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="../index.php">Volver a la Pagina Principal</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="container mt-5">
    <div class="card shadow p-4 mb-5">
        <!-- Título -->
        <div class="text-center mb-4">
            <h2>📦 Inventario de Productos</h2>
        </div>

        <!-- Buscador y Botón Exportar -->
        <form class="mb-4" method="GET">
            <div class="input-group">
                <input type="text" name="buscar" class="form-control" placeholder="Buscar producto..." value="<?= htmlspecialchars($busqueda) ?>">
                <button class="btn btn-primary" type="submit">Buscar</button>
                <a href="inventario.php" class="btn btn-secondary">Limpiar</a>
                <a href="exportar_excel.php" class="btn btn-success">📄 Exportar a Excel</a>
            </div>
        </form>

        <!-- Tabla de Inventario -->
        <div class="table-responsive mb-4">
            <table class="table table-bordered table-hover text-center">
                <thead class="table-dark">
                    <tr>
                        <th>Producto</th>
                        <th>Total Comprado</th>
                        <th>Total Vendido</th>
                        <th>Stock Disponible</th>
                        <th>Alerta</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($tabla as $row):
                        $alerta = $row['stock'] <= 5 ? '⚠️ Bajo stock' : '✅ Suficiente';
                        ?>
                        <tr class="<?= $row['stock'] <= 0 ? 'table-danger' : ($row['stock'] <= 5 ? 'table-warning' : '') ?>">
                            <td><?= htmlspecialchars($row['producto']) ?></td>
                            <td><?= $row['total_comprado'] ?></td>
                            <td><?= $row['total_vendido'] ?></td>
                            <td><?= $row['stock'] ?></td>
                            <td><?= $alerta ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Gráfico -->
        <div>
            <h4 class="mb-4 text-center">📊 Gráfico de Stock por Producto</h4>
            <canvas id="stockChart" height="100"></canvas>
        </div>
    </div>
</div>

<script>
    const ctx = document.getElementById('stockChart').getContext('2d');
    const stockChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?= json_encode($productos) ?>,
            datasets: [{
                label: 'Stock Disponible',
                data: <?= json_encode($stocks) ?>,
                backgroundColor: 'rgba(54, 162, 235, 0.6)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: { beginAtZero: true }
            }
        }
    });
</script>

<?php include '../includes/footer.php'; ?>

