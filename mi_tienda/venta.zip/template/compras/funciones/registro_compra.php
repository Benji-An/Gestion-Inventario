<?php
include '../../../db/config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $producto = trim($_POST["producto"]);
    $precio = floatval($_POST["precio"]);
    $cantidad = intval($_POST["cantidad"]);
    $proveedor = trim($_POST["proveedor"]);
    $fecha = $_POST["fecha"];
    
    // Calcular el total
    $total = $precio * $cantidad;

    // Insertar datos en la tabla compras
    $stmt = $conn->prepare("INSERT INTO compras (producto, precio, cantidad, proveedor, fecha, total) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sdissd", $producto, $precio, $cantidad, $proveedor, $fecha, $total);

    if ($stmt->execute()) {
        header("Location: ../registrar_compra.php?compra=exitosa");
        exit();
    } else {
        echo "Error al registrar la compra.";
    }

    $stmt->close();
}
?>
