<!-- ver compras -->
<?php
session_start();
if (!isset($_SESSION["usuario"])) {
    header("Location: ../auth/login.php");
    exit();
}

include '../../db/config.php';
include '../../includes/header.php';
?>

<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container">
            <a class="navbar-brand" href="#">Panel de Control</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../compras.php">Volver a la Pagina Principal del Panel de Compras</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-5">
        <div class="row mt-4">
            <div class="col-md-12">
                <div>    
                    <table class="table table-striped table-bordered table-hover table-sm">
                        <thead class="table-success text-center">
                            <tr>
                                <th colspan="7">Compras Registradas</th>
                            </tr>
                        <thead>
                            <tr>
                                <th>Producto</th>
                                <th>Precio</th>
                                <th>Cantidad</th>
                                <th>Proveedor</th>
                                <th>Fecha</th>
                                <th>Total</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $stmt = $conn->prepare("SELECT * FROM compras");
                            $stmt->execute();
                            $result = $stmt->get_result();

                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . $row["id"] . " - " . $row["producto"] . "</td>";
                                echo "<td>" . "$" . " " . $row["precio"] . "</td>";
                                echo "<td>" . $row["cantidad"] . "</td>";
                                echo "<td>" . $row["proveedor"] . "</td>";
                                echo "<td>" . $row["fecha"] . "</td>";
                                echo "<td>" . "$" . " " . $row["total"] . "</td>";
                                echo "<td>";
                                echo "<a href='actualizar_compra.php?id=" . $row["id"] . "' class='btn btn-sm btn-warning'>Actualizar</a> ";
                                echo "</td>";
                                echo "</tr>";
                            }

                            $stmt->close();
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
<?php include '../../includes/footer.php'; ?>