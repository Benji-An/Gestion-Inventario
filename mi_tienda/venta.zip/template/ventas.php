<?php
session_start();
if (!isset($_SESSION["usuario"])) {
    header("Location: auth/login.php");
    exit();
}

include '../db/config.php';
include '../includes/header.php';

?>

<body> 
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container">
            <a class="navbar-brand" href="#">Panel de Control</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">Volver a la Pagina Principal</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-5">
        <div class="text-center mb-4">
            <h2>Seccion de Ventas</h2>
        </div>

        <div class="row mt-4">
            <div class="col-md-4">
                <div class="card p-3 shadow text-center">
                    <h3>Registrar Venta</h3>
                    <a href="ventas/registrar_venta.php" class="btn btn-sm btn-outline-success">Registrar Venta</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 shadow text-center">
                    <h3>Ver Ventas</h3>
                    <a href="ventas/ver_ventas.php" class="btn btn-sm btn-outline-success">Ver Ventas</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 shadow text-center">
                    <h3>Actualizar Venta</h3>
                    <a href="ventas/actualizar_venta.php" class="btn btn-sm btn-outline-success">Actualizar Venta</a>
                </div>
            </div>
        </div>
    </div>
</body>

<?php include '../includes/footer.php'; ?>