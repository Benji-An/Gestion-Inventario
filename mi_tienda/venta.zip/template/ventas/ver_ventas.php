<?php
session_start();
if (!isset($_SESSION["usuario"])) {
    header("Location: ../auth/login.php");
    exit();
}

include '../..//db/config.php';
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Ventas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container">
            <a class="navbar-brand" href="#">Panel de Control</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../ventas.php">Volver a la Pagina Principal del Panel de ventas</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <h2 class="text-center">📊 Lista de Ventas</h2>
    <table class="table table-striped table-bordered mt-3">
        <thead>
            <tr>
                <th>ID</th>
                <th>Producto</th>
                <th>Precio</th>
                <th>Cantidad</th>
                <th>Total</th>
                <th>Cliente</th>
                <th>Fecha</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $result = $conn->query("SELECT * FROM ventas ORDER BY fecha DESC");
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["id"] . "</td>";
                echo "<td>" . $row["producto"] . "</td>";
                echo "<td>" . "$" . " " . $row["precio"] . "</td>";
                echo "<td>" . $row["cantidad"] . "</td>";
                echo "<td>" . "$" . " " . $row["total"] . "</td>";
                echo "<td>" . $row["cliente"] . "</td>";
                echo "<td>" . $row["fecha"] . "</td>";
                echo "<td>";
                echo "<a href='actualizar_venta.php?id=" . $row["id"] . "' class='btn btn-warning btn-sm'>Actualizar</a> ";
                echo "</td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
</body>
<?php include '../../includes/footer.php'; ?>
</html>
