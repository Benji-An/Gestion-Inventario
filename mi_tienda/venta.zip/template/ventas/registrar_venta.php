<!-- Registrar venta -->
<?php

include '../../db/config.php';
include '../../includes/header.php';
$productos = $conn->query("SELECT id, producto, stock_actual FROM compras WHERE stock_actual > 0");
?>

<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container">
            <a class="navbar-brand" href="#">Panel de Control</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../ventas.php">Volver a la Pagina Principal del Panel de Ventas</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-5">
        <div class="card p-4 shadow text-center">
            <h2>Registrar Venta</h2>
        </div>

        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card p-3 shadow">
                    <form action="funciones/registrar_venta.php" method="post">
                        <div class="mb-3">
                            <label for="producto_id" class="form-label">Producto</label>
                            <select name="producto_id" class="form-select" required>
                                <option value="">Seleccione un producto</option>
                                <?php while($row = $productos->fetch_assoc()): ?>
                                    <option value="<?= $row['id']; ?>">
                                        <?= $row['producto']; ?> (Stock: <?= $row['stock_actual']; ?>)
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="precio" class="form-label">Precio Unitario</label>
                            <input type="number" name="precio" step="0.01" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="cantidad" class="form-label">Cantidad</label>
                            <input type="number" name="cantidad" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="cliente" class="form-label">Cliente</label>
                            <input type="text" name="cliente" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="fecha" class="form-label">Fecha</label>
                            <input type="date" name="fecha" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-success">Registrar Venta</button>
                        <?php include '../../includes/footer.php'; ?>
                        <?php if (isset($_GET['venta']) && $_GET['venta'] == 'exitosa') : ?>
                            <div class="alert alert-success text-center mt-3">✅ Venta registrada correctamente.</div>
                        <?php endif; ?>
                        <?php if (isset($_GET['venta']) && $_GET['venta'] == 'error') : ?>
                            <div class="alert alert-danger text-center mt-3">❌ Error al registrar la venta.</div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>

</body>
