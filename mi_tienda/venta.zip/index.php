<?php
session_start();
if (!isset($_SESSION["usuario"])) {
    header("Location: auth/login.php");
    exit();
}

include 'db/config.php';
include 'includes/header.php';
?>

<body class="bg-light">
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Navbar</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#">Home</a>
                </li>
            </ul>
            <a href="auth/logout.php" class="btn btn-danger mt-3">Cerrar Sesión</a>
            </div>
        </div>
    </nav>
    <div class="container mt-5">
        <div class="card p-4 shadow text-center">
            <h2>Bienvenido, <?php echo $_SESSION["usuario"]; ?></h2>
        </div>
        <div class="row mt-4">
            <div class="col-md-4">
                <div class="card p-3 shadow text-center">
                    <h3>Sección de Compras</h3>
                    <p>En este seccion podras registrar, ver y actualizar tus compras</p>
                    <a href="template/compras.php" class="btn btn-sm btn-outline-success">Ver seccion de Compras</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 shadow text-center">
                    <h3>Sección de Ventas</h3>
                    <p>En este seccion podras registrar, ver y actualizar tus ventas</p>
                    <a href="template/ventas.php" class="btn btn-sm btn-outline-success">Ver seccion de Ventas</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 shadow text-center">
                    <h3>Inventario</h3>
                    <p>En este seccion podras ver el inventario de cuantos productos tienes</p>
                    <a href="template/inventario.php" class="btn btn-sm btn-outline-success">Ver Inventario</a>
                </div>
            </div>
            <div class="col-md-4 mt-4">
                <div class="card p-3 shadow text-center">
                    <h3>Informacion de los empleados</h3>
                    <p>En este seccion podras ver la informacion de los empleados y sus pagos</p>
                    <a href="template/ver_empleados.php" class="btn btn-sm btn-outline-success">Ver informacion</a>
                </div>
            </div>
        </div>
    </div>
</body>



<?php
// Aquí puedes agregar más contenido para el dashboard, como gráficos, estadísticas, etc.
include 'includes/footer.php';
?>